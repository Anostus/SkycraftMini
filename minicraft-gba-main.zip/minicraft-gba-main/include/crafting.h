/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#ifndef MINICRAFT_CRAFTING
#define MINICRAFT_CRAFTING

#include "minicraft.h"

#include "inventory.h"

// Increase the maximum number of ingredients per recipe to accommodate
// complex skyblock recipes (e.g., gem acorn).  The gem acorn recipe
// uses up to eleven different inputs.
#define CRAFTING_MAX_REQUIRED (11)

struct crafting_Recipe {
    struct {
        u8 items[CRAFTING_MAX_REQUIRED];
        u8 count[CRAFTING_MAX_REQUIRED];
    } required;

    u8 result;

    u8 tool_level;
};

#define WORKBENCH_RECIPES (22)
#define FURNACE_RECIPES   (10)
#define OVEN_RECIPES      (1)
#define ANVIL_RECIPES     (15)

// Number of recipes available at a basic crafting table.  The basic
// table serves as an introductory station allowing the player to
// upgrade it into a full workbench.  Only a single recipe exists
// (craft 1 workbench from 4 wood), so this value is 1.
#define BASIC_WORKBENCH_RECIPES (1)

extern const struct crafting_Recipe workbench_recipes[WORKBENCH_RECIPES];
extern const struct crafting_Recipe furnace_recipes[FURNACE_RECIPES];
extern const struct crafting_Recipe oven_recipes[OVEN_RECIPES];
extern const struct crafting_Recipe anvil_recipes[ANVIL_RECIPES];

// Recipe list for the basic crafting table.  Contains a single
// entry allowing the player to craft a normal workbench from four
// wood.
extern const struct crafting_Recipe basic_workbench_recipes[BASIC_WORKBENCH_RECIPES];

extern u8 crafting_current_recipes_size;
extern const struct crafting_Recipe *crafting_current_recipes;

extern bool crafting_craft(struct Inventory *inventory,
                           const struct crafting_Recipe *recipe);

#endif // MINICRAFT_CRAFTING
