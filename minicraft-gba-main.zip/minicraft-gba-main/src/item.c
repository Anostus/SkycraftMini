/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "item.h"

#include "tile.h"
#include "screen.h"

const struct Item item_list[ITEM_TYPES] = {
    // Wood (Plank)
    //
    // Wood is now a proper placeable block representing wooden planks
    // used for bridging gaps.  It places the new WOOD_TILE and can
    // be placed on holes (voids), on water (liquid tiles) and on the
    // infinite fall tile.  This allows players to build bridges over
    // the void and over water without support.  Grass and dirt are no
    // longer valid placement targets to free up space in the
    // placeable_on array for liquid and hole tiles.
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "WOOD",
        .palette = 0,

        .placed_tile = WOOD_TILE,
        .placeable_on = { HOLE_TILE, LIQUID_TILE, INFINITE_FALL_TILE, (u8) -1 }
    },

    // Stone
    //
    // The stone item is now a placeable block rather than just a
    // raw material. This allows players to take stones they've mined
    // and set them back down in the world to build walls.  We use
    // ROCK_TILE for the placed block so that it matches the natural
    // rock found in the overworld.  Stones can be placed on common
    // ground tiles (dirt, farmland, grass, and sand).
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "STONE",
        .palette = 1,

        .placed_tile = ROCK_TILE,
        // Allow stones to be placed back into the world as rock blocks
        // on common ground tiles.
        .placeable_on = { DIRT_TILE, FARMLAND_TILE, GRASS_TILE, SAND_TILE }
    },

    // Glass
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "GLASS",
        .palette = 1
    },

    // Wheat
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "WHEAT",
        .palette = 2
    },

    // Slime
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "SLIME",
        .palette = 1
    },

    // Cloth
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "CLOTH",
        .palette = 2
    },

    // Coal
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "COAL",
        .palette = 1
    },

    // Iron Ore
    // Make ores placeable so that players can plant veins on
    // dirt/grass/farmland.  Placing this item replaces the target
    // substrate with an iron ore tile.
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "I.ORE",
        .palette = 0,

        .placed_tile = IRON_ORE_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Gold Ore
    // Similar to iron ore, but places gold ore when planted.
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "G.ORE",
        .palette = 2,

        .placed_tile = GOLD_ORE_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Iron Ingot
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "IRON",
        .palette = 0
    },

    // Gold Ingot
    {
        .class = ITEMCLASS_MATERIAL,
        .name = "GOLD",
        .palette = 2
    },

    // Gem
    // Gems are now placeable: planting a gem creates a gem ore vein.
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "GEM",
        .palette = 2,

        .placed_tile = GEM_ORE_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // -----

    // Flower
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "FLOWER",
        .palette = 1,

        .placed_tile = FLOWER_TILE,
        .placeable_on = { GRASS_TILE, -1 }
    },

    // Seeds
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "SEEDS",
        .palette = 1,

        .placed_tile = WHEAT_TILE,
        .placeable_on = { FARMLAND_TILE, -1 }
    },

    // Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "ACORN",
        .palette = 0,

        .placed_tile = TREE_SAPLING_TILE,
        // Allow saplings to be planted on dirt and farmland in addition to grass.
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, -1 }
    },

    // Cactus
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "CACTUS",
        .palette = 1,

        .placed_tile = CACTUS_SAPLING_TILE,
        .placeable_on = { SAND_TILE, -1 }
    },

    // Dirt
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "DIRT",
        .palette = 0,

        .placed_tile = DIRT_TILE,
        // Dirt can now also be placed over the void (infinite fall)
        .placeable_on = { HOLE_TILE, LIQUID_TILE, INFINITE_FALL_TILE, -1 }
    },

    // Sand
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "SAND",
        .palette = 2,

        .placed_tile = SAND_TILE,
        // Sand can now be placed on the void for bridging islands
        .placeable_on = { GRASS_TILE, DIRT_TILE, INFINITE_FALL_TILE, -1 }
    },

    // Cloud
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "CLOUD",
        .palette = 1,

        .placed_tile = CLOUD_TILE,
        .placeable_on = { INFINITE_FALL_TILE, -1 }
    },

    // -----

    // Apple
    {
        .class = ITEMCLASS_FOOD,
        .name = "APPLE",
        .palette = 0,

        .hp_gain = 1
    },

    // Bread
    {
        .class = ITEMCLASS_FOOD,
        .name = "BREAD",
        .palette = 2,

        .hp_gain = 2
    },

    // -----

    // Workbench
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "WORKBENCH",
        .palette = 3
    },

    // Furnace
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "FURNACE",
        .palette = 1
    },

    // Oven
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "OVEN",
        .palette = 1
    },

    // Anvil
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "ANVIL",
        .palette = 1
    },

    // Chest
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "CHEST",
        .palette = 2
    },

    // Lantern
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "LANTERN",
        .palette = 1
    },

    // -----

    // Power Glove
    {
        .class = ITEMCLASS_POWERGLOVE,
        .name = "POW GLOVE",
        .palette = 0
    },

    // -----

    // Sword
    {
        .class = ITEMCLASS_TOOL,
        .name = "SWRD",
        .palette = 3
    },

    // Axe
    {
        .class = ITEMCLASS_TOOL,
        .name = "AXE",
        .palette = 3
    },

    // Pick
    {
        .class = ITEMCLASS_TOOL,
        .name = "PICK",
        .palette = 3
    },

    // Shovel
    {
        .class = ITEMCLASS_TOOL,
        .name = "SHVL",
        .palette = 3
    },

    // Hoe
    {
        .class = ITEMCLASS_TOOL,
        .name = "HOE",
        .palette = 3
    },

    // Stairs Down
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "SDOWN",
        .palette = 0,

        // When placing a stairs-down item on a hole, it actually creates
        // the stairs up tile.  This allows the player to build a way
        // back up from the lower level.
        .placed_tile = STAIRS_UP_TILE,
        // Only placeable on holes to create a ladder back up
        .placeable_on = { HOLE_TILE, (u8) -1 }
    },

    // Stairs Up
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "SUP",
        .palette = 0,

        // Placing a stairs-up item on the overworld creates the stairs
        // down tile.  This serves as the entry point to a lower level.
        .placed_tile = STAIRS_DOWN_TILE,
        // Placeable on grass, dirt or farmland to build a ladder down
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    }

    ,

    // === Skyblock Items ===

    // Time tool
    // A non-damaging tool cloned conceptually from the gem axe.  When used
    // it accelerates sapling growth by a quarter of the required ticks but
    // deals no damage to mobs.  It has its own palette to distinguish
    // it from other tools.  Rename it to "TIME WAND" in the menu to
    // better describe its magical effect.
    {
        .class = ITEMCLASS_TOOL,
        .name = "TIME WAND",
        .palette = 4
    },

    // Stone Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        // Use a concise name ("ST ACN") and a stone-themed palette.  The
        // palette index 2 corresponds to the rock palette used for stone.
        .name = "ST ACN",
        .palette = 2,

        .placed_tile = STONE_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Sand Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        // "SA ACN" for sand acorn; palette 1 corresponds to the sand palette.
        .name = "SA ACN",
        .palette = 1,

        .placed_tile = SAND_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Iron Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        // "IR ACN" for iron acorn; palette 3 matches the ore palette used
        // for iron ore.
        .name = "IR ACN",
        .palette = 3,

        .placed_tile = IRON_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Gold Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        // "GD ACN" for gold acorn; palette 6 matches the hard rock / gold
        // palette used for gold tiles.
        .name = "GD ACN",
        .palette = 6,

        .placed_tile = GOLD_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Gem Acorn
    {
        .class = ITEMCLASS_PLACEABLE,
        // "GM ACN" for gem acorn; palette 5 corresponds to the infinite
        // fall / gem hue used for gem trees.
        .name = "GM ACN",
        .palette = 5,

        .placed_tile = GEM_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    },

    // Dirt Acorn
    //
    // Plants the dirt sapling which grows into a dirt tree.  This
    // acorn is separate from the base acorn and is used exclusively
    // for dirt production.  Use the name "D ACN" and palette 4 to
    // distinguish it while keeping within the valid palette range.
    {
        .class = ITEMCLASS_PLACEABLE,
        .name = "D ACN",
        .palette = 4,

        .placed_tile = DIRT_SAPLING_TILE,
        .placeable_on = { GRASS_TILE, DIRT_TILE, FARMLAND_TILE, (u8) -1 }
    }

    ,

    // Basic Crafting Table
    //
    // A minimalist crafting table that provides a single recipe to
    // upgrade itself into a full workbench.  It behaves as a
    // furniture item.  Placement of this item creates a basic
    // crafting table entity rather than a normal workbench.  Use a
    // different palette (5) so that the basic table can be tinted
    // differently from the standard workbench when drawn and held.
    {
        .class = ITEMCLASS_FURNITURE,
        .name = "B.WORK",
        .palette = 5
    }
};

THUMB
void item_write(struct item_Data *data, u8 palette, u32 x, u32 y) {
    const struct Item *item = ITEM_S(data);

    if(item_is_resource(data->type)) {
        u16 count = data->count;
        if(count > 999)
            count = 999;

        SCREEN_WRITE_NUMBER(count, 10, 3, false, palette + 3, x, y);
        screen_write(item->name, palette, x + 3, y);
    } else {
        item_write_name(data, palette, x, y);
    }
}

static const char level_names[5][5] = {
    "WOOD", "ROCK", "IRON", "GOLD", "GEM"
};

THUMB
void item_write_name(struct item_Data *data, u8 palette, u32 x, u32 y) {
    const struct Item *item = ITEM_S(data);

    // The Time Wand is implemented as a tool (for interaction behavior),
    // but it should not display a material prefix like "WOOD" in menus.
    // Keep its functionality and tool-level data unchanged; only alter the
    // rendered name for the UI.
    if(data->type == TIME_ITEM) {
        screen_write(item->name, palette, x, y);
        return;
    }

    if(item->class == ITEMCLASS_TOOL) {
        const u8 level = data->tool_level;

        screen_write(level_names[level], palette, x, y);
        screen_write(item->name, palette, x + 4 + (level != 4), y);
    } else {
        screen_write(item->name, palette, x, y);
    }
}

THUMB
void item_draw_icon(struct item_Data *data, u32 x, u32 y, bool black_bg) {
    const struct Item *item = ITEM_S(data);

    // Map variant acorn items back to the base acorn icon.  When drawing
    // any of the resource acorns (dirt, stone, sand, iron, gold, gem),
    // reuse the tile for ACORN_ITEM so that they share the same thumbnail.
    // Also map the basic crafting table to the workbench tile so that
    // both crafting tables display the same icon.
    u8 draw_type = data->type;
    if(draw_type == DIRT_ACORN_ITEM || draw_type == STONE_ACORN_ITEM ||
       draw_type == SAND_ACORN_ITEM || draw_type == IRON_ACORN_ITEM ||
       draw_type == GOLD_ACORN_ITEM || draw_type == GEM_ACORN_ITEM) {
        draw_type = ACORN_ITEM;
    } else if(draw_type == BASIC_WORKBENCH_ITEM) {
        draw_type = WORKBENCH_ITEM;
    }

    const u16 tile = 128 + draw_type +
                     (item->class == ITEMCLASS_TOOL) * (2 + data->tool_level * 5);
    const u8 palette = (black_bg == false) * (12 + item->palette) +
                       (black_bg == true) * 11;

    BG3_TILEMAP[x + y * 32] = tile | palette << 12;
}
