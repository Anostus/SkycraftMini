/* Copyright 2022-2024 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "screen.h"

/*
 * Include definitions for the dynamically allocated tile indices used by
 * the new resource tree variants.  These macros define the base tile
 * indices for each tree's leaf and sapling tiles.  See
 * new_tiles.h for details.
 */
#include "new_tiles.h"

#include "res/palettes/background.c"
#include "res/palettes/sprites.c"
#include "res/palettes/items.c"

#include "res/images/level.c"
#include "res/images/logo.c"
#include "res/images/font.c"
#include "res/images/gui.c"
#include "res/images/items_bg.c"
#include "res/images/level-light.c"

#include "res/images/entities.c"
#include "res/images/sparks.c"
#include "res/images/items_spr.c"
#include "res/images/player-light.c"
#include "res/images/player-lantern-light.c"
#include "res/images/text-particle.c"

/*
 * Palette/tileset helpers
 *
 * Some builds of libsimplegba do not export the convenience symbols
 * BG_PALETTE / SPR_PALETTE and helper macros. The notebook build
 * environment you provided is one of those, so we define stable
 * fallbacks here to keep the project self-contained.
 */

#ifndef BG_PALETTE
#define BG_PALETTE ((volatile u16*)0x05000000)
#endif

#ifndef SPR_PALETTE
#define SPR_PALETTE ((volatile u16*)0x05000200)
#endif

#ifndef LOAD_TILESET
#define LOAD_TILESET(charblock, offset, tileset) \
    memory_copy_32(                            \
        display_charblock(charblock) + (offset) * 16, \
        tileset,                                      \
        sizeof(tileset)                               \
    )
#endif

#ifndef LOAD_PALETTE
#define LOAD_PALETTE(dest, palette) \
    memory_copy_32(dest, palette, sizeof(palette))
#endif

/*
 * New background palette for resource trees (palette index 7).
 * This palette copies the trunk and UI colours from palette 0 and
 * replaces the green leaf indices (1–7) with unique colours for
 * dirt, stone, sand, iron, gold and gem resource trees.  The
 * remaining entries (8–15) mirror the original palette 0 values.
 *
 * Colour values are encoded in 15‑bit BGR format where bits 0–4 are
 * red, 5–9 are green and 10–14 are blue.  See GBA technical
 * documentation for details.
 */
static const u16 new_bg_palette_7[16] = {
    /*  0: transparent magenta (unchanged)        */ 0x7c1f,
    /*  1: dirt leaf (brown)                      */ 0x1971,
    /*  2: stone leaf (grey)                      */ 0x4210,
    /*  3: sand leaf (tan)                        */ 0x2f1b,
    /*  4: iron leaf (dark steel)                 */ 0x316b,
    /*  5: gold leaf (yellow)                     */ 0x1aba,
    /*  6: gem leaf (cyan)                        */ 0x7f29,
    /*  7: unused/green (copy of original index7) */ 0x372d,
    /*  8: trunk colour 1 (copy of palette0 index8)  */ 0x1d8f,
    /*  9: trunk colour 2 (copy of palette0 index9)  */ 0x2655,
    /* 10: trunk colour 3 (copy of palette0 index10) */ 0x2ed6,
    /* 11: grass base (copy of palette0 index1)   */ 0x328c,
    /* 12: dark accent (copy of palette0 index12) */ 0x1cea,
    /* 13: mid grey   (copy of palette0 index13) */ 0x35b0,
    /* 14: light accent(copy of palette0 index14) */ 0x7bde,
    /* 15: shadow colour (copy of palette0 index15)*/ 0x0421
};

/*
 * Resource tree tile generation
 *
 * We clone the base tree tiles (34–39) and sapling tiles (56–71) from the
 * normal level tileset into unused tile IDs and remap only the foliage
 * pixels. This avoids the "grass recoloured instead of leaves" bug by
 * keeping the sapling's grass background pixels on a dedicated palette
 * entry (index 11), which is set to the normal grass green in
 * new_bg_palette_7.
 *
 * Notes:
 *  - Tree foliage uses palette indices 1–7 in palette 0.
 *  - Sapling grass background uses palette index 1 in palette 0.
 *  - Trunk/shading indices (8–10,12–15) are preserved.
 */

#define RESOURCE_TREE_SRC_BASE     (34)
#define RESOURCE_SAPLING_SRC_BASE  (56)

/*
 * Palette index in palette 7 that we reserve for normal grass green.
 * (Matches new_bg_palette_7[11].)
 */
#define RESOURCE_GRASS_INDEX       (11)

/*
 * Some sapling/grass tiles use multiple "green" indices (1–7) for
 * shading. Palette 7 repurposes indices 1–6 for resource colours, so
 * background greens must be remapped to safe green slots.
 *
 * Strategy:
 *  - For pixels NOT belonging to the sapling sprite, remap greens to
 *    either:
 *      * RESOURCE_GRASS_INDEX (index 11): grass base
 *      * 7: highlight green (palette 7 keeps index 7 as green)
 *  - For pixels belonging to the sapling sprite, remap greens 1–7 to
 *    the resource leaf index (1–6), and remap outline index 4 to a dark
 *    shadow colour (15).
 *
 * The "sapling sprite pixels" are determined automatically from the
 * base tileset by finding the closest matching non-sapling background
 * tile for each of the 16 sapling adjacency tiles (56–71), then taking
 * a small connected-component mask of the differing pixels. This avoids
 * recolouring grass/ground shading while still tinting the sapling.
 */

static inline volatile u32 *tile_ptr_u32(u16 tile_id) {
    return (volatile u32 *)((volatile u16 *)display_charblock(0) + tile_id * 16);
}


static inline u8 get_pixel_4bpp(u16 tile_id, u32 x, u32 y) {
    volatile u32 *t = tile_ptr_u32(tile_id);
    u32 row = t[y & 7];
    return (row >> ((x & 7) * 4)) & 0xF;
}

static inline u32 nibble_mismatch_count(u32 a, u32 b) {
    if(a == b) return 0;
    u32 x = a ^ b;
    u32 c = 0;
    for(u32 i = 0; i < 8; i++) {
        if(((x >> (i * 4)) & 0xF) != 0)
            c++;
    }
    return c;
}

static u32 tile_mismatch_pixels(u16 a_tile, u16 b_tile) {
    volatile u32 *a = tile_ptr_u32(a_tile);
    volatile u32 *b = tile_ptr_u32(b_tile);

    u32 mism = 0;
    for(u32 y = 0; y < 8; y++)
        mism += nibble_mismatch_count(a[y], b[y]);
    return mism;
}

/*
 * Find a "background-only" tile that most closely matches a given
 * source tile. We search within the original (non-variant) tile range
 * [0, DIRT_TREE_TILE_BASE), excluding tree and sapling source tiles.
 *
 * This lets us isolate overlay pixels (tree foliage / sapling sprite)
 * as the differences between the source tile and its best background match.
 */
static u16 find_best_background_tile(u16 src_tile) {
    u16 best = 0;
    u32 best_diff = 0xFFFFFFFFu;

    for(u16 cand = 0; cand < DIRT_TREE_TILE_BASE; cand++) {
        // Exclude tree tiles (34–39) and sapling tiles (56–71)
        if(cand >= RESOURCE_TREE_SRC_BASE &&
           cand <  RESOURCE_TREE_SRC_BASE + RESOURCE_TREE_TILES_PER_VARIANT)
            continue;
        if(cand >= RESOURCE_SAPLING_SRC_BASE &&
           cand <  RESOURCE_SAPLING_SRC_BASE + RESOURCE_SAPLING_TILES_PER_VARIANT)
            continue;

        if(cand == src_tile)
            continue;

        u32 d = tile_mismatch_pixels(src_tile, cand);
        if(d < best_diff) {
            best_diff = d;
            best = cand;
            if(best_diff == 0)
                break;
        }
    }

    return best;
}

/*
 * Build a per-tile pixel mask for the sapling sprite.
 *
 * Step 1: diff-mask between sapling tile and best background match
 * Step 2: keep only small connected components of that diff mask,
 *         which correspond to the sapling sprite overlay (tiny),
 *         and discard large components (ground/edge differences).
 *
 * Returns a 64-bit mask; bit (y*8 + x) corresponds to pixel (x,y).
 */
static u64 build_sapling_sprite_mask(u16 sapling_src_tile) {
    u16 bg = find_best_background_tile(sapling_src_tile);

    // Build initial diff mask
    u64 diff_mask = 0;
    for(u32 y = 0; y < 8; y++) {
        for(u32 x = 0; x < 8; x++) {
            u8 a = get_pixel_4bpp(sapling_src_tile, x, y);
            u8 b = get_pixel_4bpp(bg, x, y);
            if(a != b)
                diff_mask |= (1ull << (y * 8 + x));
        }
    }

    // Connected component filtering
    u64 visited = 0;
    u64 keep = 0;

    // Threshold tuned for the tiny sapling sprite; any larger region is
    // almost certainly an edge/ground mismatch between tiles.
    const u32 MAX_COMP_SIZE = 20;

    while((diff_mask & ~visited) != 0) {
        // Find a starting bit
        u32 start = 0;
        for(; start < 64; start++) {
            if(((diff_mask & ~visited) >> start) & 1ull)
                break;
        }
        if(start >= 64)
            break;

        // BFS over 4-neighbourhood
        u8 queue[64];
        u32 qh = 0, qt = 0;

        queue[qt++] = (u8)start;
        visited |= (1ull << start);

        u64 comp_bits = 0;
        u32 comp_size = 0;

        while(qh < qt) {
            u32 p = queue[qh++];
            comp_bits |= (1ull << p);
            comp_size++;

            u32 x = p & 7;
            u32 y = p >> 3;

            // Neighbours
            const u32 nbs[4] = {
                (x > 0) ? (p - 1) : 0xFFFFFFFFu,
                (x < 7) ? (p + 1) : 0xFFFFFFFFu,
                (y > 0) ? (p - 8) : 0xFFFFFFFFu,
                (y < 7) ? (p + 8) : 0xFFFFFFFFu
            };

            for(u32 i = 0; i < 4; i++) {
                u32 np = nbs[i];
                if(np == 0xFFFFFFFFu)
                    continue;
                u64 bit = 1ull << np;
                if((diff_mask & bit) && !(visited & bit)) {
                    visited |= bit;
                    queue[qt++] = (u8)np;
                }
            }
        }

        if(comp_size > 0 && comp_size <= MAX_COMP_SIZE)
            keep |= comp_bits;
    }

    return keep;
}

static void compute_sapling_sprite_masks(u64 masks[RESOURCE_SAPLING_TILES_PER_VARIANT]) {
    for(u32 i = 0; i < RESOURCE_SAPLING_TILES_PER_VARIANT; i++)
        masks[i] = build_sapling_sprite_mask(RESOURCE_SAPLING_SRC_BASE + i);
}

/*
 * Clone + recolor a sapling tile, recolouring only the pixels selected
 * by 'sprite_mask' and keeping ground/grass pixels green.
 */
static void clone_recolor_sapling_tile_4bpp(u16 src_tile, u16 dst_tile, u8 leaf_index, u64 sprite_mask) {
    volatile u32 *src = tile_ptr_u32(src_tile);
    volatile u32 *dst = tile_ptr_u32(dst_tile);

    for(u32 y = 0; y < 8; y++) {
        u32 row = src[y];
        u32 out = 0;

        for(u32 x = 0; x < 8; x++) {
            u8 idx = (row >> (x * 4)) & 0xF;
            bool in_sprite = ((sprite_mask >> (y * 8 + x)) & 1ull) != 0;

            if(in_sprite) {
                if(idx == 4) {
                    idx = 15; // dark outline/shadow
                } else if(idx >= 1 && idx <= 7) {
                    idx = leaf_index; // tint sapling foliage
                }
            } else {
                // keep ground greens green when using palette 7
                if(idx == 1) {
                    idx = RESOURCE_GRASS_INDEX; // grass base
                } else if(idx >= 2 && idx <= 7) {
                    idx = 7; // keep highlight/secondary greens green
                }
            }

            out |= ((u32)idx) << (x * 4);
        }

        dst[y] = out;
    }
}


static u64 build_tree_foliage_mask(u16 tree_src_tile) {
    /*
     * Tree tiles use two different green families:
     *   - grass/background base: index 1 (must stay green)
     *   - dark leaf outline/shadow: index 4 (should stay dark, not tinted)
     *   - leaf fill/highlights: the remaining green indices (commonly 3 and 7)
     *
     * The previous diff-based mask often picked up the outline instead of the
     * fill. For trees we can build a more reliable semantic mask directly from
     * palette indices: recolour only green pixels except grass-base (1) and the
     * dark outline/shadow green (4).
     */
    u64 mask = 0;
    for(u32 y = 0; y < 8; y++) {
        for(u32 x = 0; x < 8; x++) {
            u8 a = get_pixel_4bpp(tree_src_tile, x, y);
            if(a >= 1 && a <= 7 && a != 1 && a != 4)
                mask |= (1ull << (y * 8 + x));
        }
    }
    return mask;
}

static void compute_tree_foliage_masks(u64 masks[RESOURCE_TREE_TILES_PER_VARIANT]) {
    for(u32 i = 0; i < RESOURCE_TREE_TILES_PER_VARIANT; i++)
        masks[i] = build_tree_foliage_mask(RESOURCE_TREE_SRC_BASE + i);
}

static void clone_recolor_tree_tile_4bpp(u16 src_tile, u16 dst_tile, u8 leaf_index, u64 foliage_mask) {
    volatile u32 *src = tile_ptr_u32(src_tile);
    volatile u32 *dst = tile_ptr_u32(dst_tile);

    for(u32 y = 0; y < 8; y++) {
        u32 row = src[y];
        u32 out = 0;

        for(u32 x = 0; x < 8; x++) {
            u8 idx = (row >> (x * 4)) & 0xF;
            bool in_foliage = ((foliage_mask >> (y * 8 + x)) & 1ull) != 0;

            if(in_foliage) {
                // Tint only the leaf fill/highlight greens; keep dark outline (4) intact.
                if(idx >= 1 && idx <= 7 && idx != 1 && idx != 4)
                    idx = leaf_index;
            } else {
                // Preserve grass/ground greens under palette 7. Keep dark outline (4) unchanged.
                if(idx == 1) idx = RESOURCE_GRASS_INDEX;
                else if(idx >= 2 && idx <= 7 && idx != 4) idx = 7;
            }

            out |= ((u32)idx) << (x * 4);
        }

        dst[y] = out;
    }
}

static void build_resource_variant_tiles(u16 tree_dst_base,
                                        u16 sapling_dst_base,
                                        u8 leaf_index,
                                        const u64 tree_masks[RESOURCE_TREE_TILES_PER_VARIANT],
                                        const u64 sapling_masks[RESOURCE_SAPLING_TILES_PER_VARIANT]) {
    // Clone + recolor the full tree tile set (34–39), foliage-only via mask
    for(u32 i = 0; i < RESOURCE_TREE_TILES_PER_VARIANT; i++)
        clone_recolor_tree_tile_4bpp(RESOURCE_TREE_SRC_BASE + i,
                                     tree_dst_base + i,
                                     leaf_index,
                                     tree_masks[i]);

    // Clone + recolor the full sapling tile set (56–71), foliage-only via mask
    for(u32 i = 0; i < RESOURCE_SAPLING_TILES_PER_VARIANT; i++)
        clone_recolor_sapling_tile_4bpp(RESOURCE_SAPLING_SRC_BASE + i,
                                        sapling_dst_base + i,
                                        leaf_index,
                                        sapling_masks[i]);
}

static void build_resource_tiles(void) {
    u64 tree_masks[RESOURCE_TREE_TILES_PER_VARIANT];
    u64 sapling_masks[RESOURCE_SAPLING_TILES_PER_VARIANT];

    compute_tree_foliage_masks(tree_masks);
    compute_sapling_sprite_masks(sapling_masks);

    build_resource_variant_tiles(DIRT_TREE_TILE_BASE,  DIRT_SAPLING_TILE_BASE,  1, tree_masks, sapling_masks);
    build_resource_variant_tiles(STONE_TREE_TILE_BASE, STONE_SAPLING_TILE_BASE, 2, tree_masks, sapling_masks);
    build_resource_variant_tiles(SAND_TREE_TILE_BASE,  SAND_SAPLING_TILE_BASE,  3, tree_masks, sapling_masks);
    build_resource_variant_tiles(IRON_TREE_TILE_BASE,  IRON_SAPLING_TILE_BASE,  4, tree_masks, sapling_masks);
    build_resource_variant_tiles(GOLD_TREE_TILE_BASE,  GOLD_SAPLING_TILE_BASE,  5, tree_masks, sapling_masks);
    build_resource_variant_tiles(GEM_TREE_TILE_BASE,   GEM_SAPLING_TILE_BASE,   6, tree_masks, sapling_masks);
}



void screen_init(void) {
    display_config(0);

    window_config(WINDOW_OUT, NULL);

    // Filter out the light layer when inside OBJ Window
    window_config(WINDOW_SPR, &(struct Window) {
        .bg0 = true,
        .bg1 = true,
        .bg2 = false,
        .bg3 = true,

        .sprites = true,

        .effects = true
    });
    window_toggle(WINDOW_SPR, true);

    // Sky Background
    background_config(BG0, &(struct Background) {
        .priority = 3,
        .tileset  = 0,
        .tilemap  = 16
    });

    // Level Tiles
    background_config(BG1, &(struct Background) {
        .priority = 2,
        .tileset  = 0,
        .tilemap  = 17
    });

    // Light system
    background_config(BG2, &(struct Background) {
        .priority = 1,
        .tileset  = 1,
        .tilemap  = 18
    });

    // Text and GUI
    background_config(BG3, &(struct Background) {
        .priority = 0,
        .tileset  = 1,
        .tilemap  = 19
    });

    // enable backgrounds
    background_toggle(BG1, true); // level tiles
    background_toggle(BG3, true); // text and GUI

    // load palettes
    LOAD_PALETTE(BG_PALETTE, background_palette);
    LOAD_PALETTE(SPR_PALETTE, sprites_palette);

    LOAD_PALETTE(BG_PALETTE  + 12 * 16, items_palette);
    LOAD_PALETTE(SPR_PALETTE + 12 * 16, items_palette);

    /*
     * Replace the default cloud palette (palette 7) with our custom
     * resource tree palette.  This frees up palette 7 by moving the
     * cloud graphics to palette 6 (see draw/tiles.c) and provides a
     * unified palette that includes six distinct leaf colours for
     * resource trees while retaining the original trunk and shading
     * colours.  The palette table is updated here once during
     * initialization.
     */
    LOAD_PALETTE(BG_PALETTE + 7 * 16, new_bg_palette_7);

    // make the first tile of charblock 1 fully transparent
    memory_set_32(display_charblock(1), 0x00, 32);

    // load tilesets
    LOAD_TILESET(0, 0, level_tileset);
    // build resource tree/sapling variant tiles after the base tileset is loaded
    build_resource_tiles();
    LOAD_TILESET(1, 1, logo_tileset);
    LOAD_TILESET(1, 32, font_tileset);
    LOAD_TILESET(1, 96, gui_tileset);
    LOAD_TILESET(1, 128, items_bg_tileset);
    LOAD_TILESET(1, 192, level_light_tileset);

    LOAD_TILESET(4, 0, entities_tileset);
    LOAD_TILESET(4, 192, sparks_tileset);
    LOAD_TILESET(4, 256, items_spr_tileset);
    LOAD_TILESET(4, 320, player_light_tileset);
    LOAD_TILESET(4, 336, player_lantern_light_tileset);

    // load font sprites
    for(u32 i = 0; i <= 51; i++) {
        vu16 *dest = display_charblock(4) + (640 + i * 2) * 16;
        memory_copy_32(
            dest,
            (u8 *) (text_particle_tileset) + (i / 10) * 32,
            32
        );
        memory_copy_32(
            dest + 16,
            (u8 *) (text_particle_tileset) + (i % 10) * 32,
            32
        );
    }

    // set sky background
    for(u32 y = 0; y <= 18; y++)
        for(u32 x = 0; x <= 30; x++)
            BG0_TILEMAP[x + y * 32] = 0 | 9 << 12;

    // prepare prestart screen
    display_brighten(NULL, 16);
    for(u32 y = 0; y < 20; y++)
        for(u32 x = 0; x < 30; x++)
            BG3_TILEMAP[x + y * 32] = 32;

    sprite_hide(-1);

    // disable forced blank
    display_force_blank(false);
}

IWRAM_SECTION
void screen_write(const char *text, u8 palette, u32 x, u32 y) {
    const u32 x0 = x;

    for(u32 i = 0; text[i] != '\0'; i++) {
        const char c = text[i];

        if(c == '\n') {
            x = x0;
            y++;

            if(y >= 20)
                break;
        } else {
            if(x >= 30)
                continue;

            u16 tile = c; // font tiles match ASCII values
            BG3_TILEMAP[x + y * 32] = tile | palette << 12;

            x++;
        }
    }
}

THUMB
void screen_draw_frame(const char *title, u32 x, u32 y, u32 w, u32 h) {
    w--;
    h--;

    // draw corners
    BG3_TILEMAP[(x)     + (y)     * 32] = 96 | 0 << 10 | 6 << 12;
    BG3_TILEMAP[(x + w) + (y)     * 32] = 96 | 1 << 10 | 6 << 12;
    BG3_TILEMAP[(x)     + (y + h) * 32] = 96 | 2 << 10 | 6 << 12;
    BG3_TILEMAP[(x + w) + (y + h) * 32] = 96 | 3 << 10 | 6 << 12;

    // draw vertical borders
    for(u32 yi = y + 1; yi <= y + h - 1; yi++) {
        BG3_TILEMAP[(x)     + yi * 32] = 98 | 0 << 10 | 6 << 12;
        BG3_TILEMAP[(x + w) + yi * 32] = 98 | 1 << 10 | 6 << 12;

        // draw background
        for(u32 xi = x + 1; xi <= x + w - 1; xi++)
            BG3_TILEMAP[xi + yi * 32] = 99 | 6 << 12;
    }

    // draw horizontal borders
    for(u32 xi = x + 1; xi <= x + w - 1; xi++) {
        BG3_TILEMAP[xi + (y)     * 32] = 97 | 0 << 10 | 6 << 12;
        BG3_TILEMAP[xi + (y + h) * 32] = 97 | 2 << 10 | 6 << 12;
    }

    screen_write(title, 10, x + 1, y);
}

static inline u32 ticks_to_seconds(u32 ticks) {
    // refresh time:    280_896    cycles = 4389   * 64 cycles
    // clock frequency: 16_777_216 Hz     = 262144 * 64 Hz
    //
    // framerate = (clock frequency) / (refresh time)
    // time = ticks / framerate
    //      = (ticks * 4389) / 262144
    //      = (ticks * 4389) >> 18

    return (((u64) ticks) * 4389) >> 18;
}

void screen_write_time(u32 ticks, u8 palette, u32 x, u32 y) {
    // NOTE this is different from the original game: here, seconds are
    // displayed even if hours is not 0 and there is a space between the
    // hours and minutes values.

    u32 seconds = ticks_to_seconds(ticks);
    u32 minutes = seconds / 60;
    u32 hours   = minutes / 60;

    seconds %= 60;
    minutes %= 60;

    char text[15] = { 0 };

    u8 offset = 0;
    if(hours > 0) {
        itoa(hours, 10, text, 5, false);
        offset += 1 + (hours > 9)   + (hours > 99) +
                      (hours > 999) + (hours > 9999);
        text[offset++] = 'H';
        text[offset++] = ' ';
    }

    itoa(minutes, 10, text + offset, 2, true);
    offset += 2;
    text[offset++] = 'M';
    text[offset++] = ' ';

    itoa(seconds, 10, text + offset, 2, true);
    offset += 2;
    text[offset++] = 'S';

    screen_write(text, palette, x, y);
}

void screen_set_bg_palette_color(u8 palette, u8 index, u16 color) {
    BG_PALETTE[palette * 16 + index] = color;
}

void screen_load_active_item_palette(u8 palette) {
    memory_copy_32(BG_PALETTE + 11 * 16, items_palette + 16 * palette, 32);
    screen_set_bg_palette_color(11, 15, 0x0421);
}

void screen_update_level_specific(void) {
    background_toggle(BG0, current_level == 4); // sky background
    background_toggle(BG2, current_level < 3);  // light layer

    // dirt color
    const u16 dirt_colors[5][2] = {
        { 0x1ce7, 0x318c },
        { 0x1ce7, 0x318c },
        { 0x1ce7, 0x318c },
        { 0x1cea, 0x35b0 },
        { -1,     0x6318 }
    };
    for(u32 i = 0; i <= 3; i++) {
        screen_set_bg_palette_color(i, 12, dirt_colors[current_level][0]);
        screen_set_bg_palette_color(i, 13, dirt_colors[current_level][1]);
    }
    screen_set_bg_palette_color(0, 0, dirt_colors[current_level][1]);

    screen_set_bg_palette_color(8, 2, dirt_colors[current_level][0]);
    screen_set_bg_palette_color(8, 1, dirt_colors[current_level][1]);

    // farmland
    const u16 farmland_colors[5][2] = {
        { 0x1cea, 0x1445 },
        { 0x1cea, 0x1445 },
        { 0x1cea, 0x1445 },
        { 0x210e, 0x1869 },
        { -1, -1 }
    };
    screen_set_bg_palette_color(4, 4, farmland_colors[current_level][0]);
    screen_set_bg_palette_color(4, 5, farmland_colors[current_level][1]);

    // ore/cloud cactus
    const u16 ore_colors[5][3] = {
        { 0x733c, 0x44b1, 0x1445 }, // gem
        { 0x5fbd, 0x2ed6, 0x0cc6 }, // gold
        { 0x673b, 0x35b0, 0x0844 }, // iron
        { -1, -1, -1 },
        { 0x7bde, 0x4a52, 0x1ce7 }  // cloud cactus
    };
    screen_set_bg_palette_color(3, 6, ore_colors[current_level][0]);
    screen_set_bg_palette_color(3, 5, ore_colors[current_level][1]);
    screen_set_bg_palette_color(3, 4, ore_colors[current_level][2]);

    // liquid
    const u16 liquid_colors[2][2] = {
        { 0x14b3, 0x21d7 },
        { 0x4442, 0x4d08 }
    };
    for(u32 i = 3; i <= 4; i++) {
        screen_set_bg_palette_color(i, 1, liquid_colors[current_level > 0][0]);
        screen_set_bg_palette_color(i, 2, liquid_colors[current_level > 0][1]);
        screen_set_bg_palette_color(i, 3, liquid_colors[current_level > 0][0]);
    }
}
