/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "scene.h"

#include "screen.h"
#include "storage.h"
#include "sound.h"

// Cheat code support (pause menu only)
#include "player.h"

static bool ask_overwrite;
static u8 selected_answer;

static bool should_save = false;

// Press UP 10 times on the pause menu to receive items.
static u8 cheat_up_presses;
static bool cheat_triggered;

THUMB
static void pause_cheat_give_items(void) {
    // Resources / placeables
    inventory_add_resource(&player_inventory, GEM_ITEM,        99, 0);
    inventory_add_resource(&player_inventory, GEM_ACORN_ITEM,  10, 0);
    inventory_add_resource(&player_inventory, STAIRS_UP_ITEM,   5, 0);
    inventory_add_resource(&player_inventory, STAIRS_DOWN_ITEM, 5, 0);

    // Gem tools (tool_level = 4)
    struct item_Data tool;

    tool.type = SWORD_ITEM;
    tool.tool_level = 4;
    inventory_add(&player_inventory, &tool, 0);

    tool.type = AXE_ITEM;
    tool.tool_level = 4;
    inventory_add(&player_inventory, &tool, 0);

    tool.type = PICK_ITEM;
    tool.tool_level = 4;
    inventory_add(&player_inventory, &tool, 0);

    tool.type = SHOVEL_ITEM;
    tool.tool_level = 4;
    inventory_add(&player_inventory, &tool, 0);

    tool.type = HOE_ITEM;
    tool.tool_level = 4;
    inventory_add(&player_inventory, &tool, 0);

    SOUND_PLAY(sound_pickup);
}

THUMB
static void pause_init(u8 flags) {
    ask_overwrite = false;

    cheat_up_presses = 0;
    cheat_triggered = false;
}

THUMB
static void pause_tick(void) {
    // --- Cheat code detection (pause menu) ---
    if(!cheat_triggered && input_press(KEY_UP)) {
        cheat_up_presses++;
        if(cheat_up_presses >= 10) {
            cheat_triggered = true;
            pause_cheat_give_items();
        }
    }

    if(should_save) {
        storage_save();
        SOUND_PLAY(sound_start);

        should_save = false;
        ask_overwrite = false;
    }

    if(input_press(KEY_START))
        set_scene(&scene_game, 1);

    if(input_repeat(KEY_A)) {
        if(ask_overwrite) {
            if(selected_answer == 1)
                ask_overwrite = false;
            else
                should_save = true;
        } else if(storage_check()) {
            ask_overwrite = true;
            selected_answer = 0;
        } else {
            should_save = true;
        }
    }

    if(input_repeat(KEY_B))
        ask_overwrite = false;

    if(ask_overwrite && (input_repeat(KEY_LEFT) || input_repeat(KEY_RIGHT)))
        selected_answer ^= 1;
}

/*
 * Write an option in the pause menu.  Both selected and unselected
 * options now use palette 6.  Selection is indicated purely by
 * arrow markers to either side of the text.  Palette 7 has been
 * reclaimed for resource tree graphics and is no longer used for
 * interface text.
 */
#define WRITE_OPTION(text, id, x, y) do {\
    screen_write((text), 6, (x), (y));\
\
    if(selected_answer == (id)) {\
        screen_write(">", 6, (x) - 2, (y));\
        screen_write("<", 6, (x) + sizeof(text), (y));\
    }\
} while(0)

THUMB
static void pause_draw(void) {
    const u8 pause_x = 6;
    const u8 pause_y = 5;
    const u8 pause_w = 18;
    const u8 pause_h = 8;

    screen_draw_frame("PAUSE", pause_x, pause_y, pause_w, pause_h);

    screen_write("TIME:", 6, pause_x + 1, pause_y + 1);
    screen_write_time(gametime, 10, pause_x + 6, pause_y + 1);

    screen_write("SCORE:", 6, pause_x + 1, pause_y + 2);
    SCREEN_WRITE_NUMBER(score, 10, 10, false, 10, pause_x + 7, pause_y + 2);

    if(should_save) {
        screen_write("SAVING...", 6, pause_x + 5, pause_y + 5);
    } else if(ask_overwrite) {
        screen_write("OVERWRITE FILE?", 6, pause_x + 1, pause_y + 4);

        WRITE_OPTION("YES", 0, pause_x + 4,  pause_y + 6);
        WRITE_OPTION("NO",  1, pause_x + 12, pause_y + 6);
    } else {
        screen_write("> SAVE GAME <", 6, pause_x + 2, pause_y + 5);
    }
}

const struct Scene scene_pause = {
    .init = pause_init,

    .tick = pause_tick,
    .draw = pause_draw
};
