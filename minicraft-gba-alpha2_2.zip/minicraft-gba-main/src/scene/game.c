/* Copyright 2022-2023 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "scene.h"

#include "level.h"
#include "screen.h"
#include "mob.h"
#include "player.h"
// For TOP_LEVEL_SPAWN_* constants used as a safe fallback when transitioning
// into the top level and no matching stairs exist.
#include "generator.h"

// Include tile definitions for STAIRS_UP_TILE and STAIRS_DOWN_TILE.  If the
// project being built does not provide these macros via tile.h (for example
// when an older version of the headers is used), we provide fallback
// definitions below so that the code will still compile.  These values
// correspond to the enumerations defined in the modified skyblock version
// of the game: stairs down is tile 13 and stairs up is tile 14.
#include "tile.h"

// Fallback definitions for STAIRS_UP_TILE and STAIRS_DOWN_TILE.  In case
// tile.h does not define them (e.g. in older code bases), define them
// manually to the expected tile indices.  The `#ifndef` guards ensure
// that if they are already defined by tile.h, these definitions are not
// used and thus do not conflict with the canonical values.
#ifndef STAIRS_DOWN_TILE
#define STAIRS_DOWN_TILE 13
#endif

#ifndef STAIRS_UP_TILE
#define STAIRS_UP_TILE 14
#endif

static struct Level *level = NULL;

static bool should_clear = false;

static inline void game_move_player(struct Level *old_level,
                                    struct Level *new_level) {
    struct entity_Data *new_player = &new_level->entities[0];

    // Copy the player entity from the old level into the new level
    *new_player = old_level->entities[0];
    u16 old_player_x = new_player->x;
    u16 old_player_y = new_player->y;

    // Determine the tile coordinates of the player's previous position
    u8 old_xt = old_player_x >> 4;
    u8 old_yt = old_player_y >> 4;

    // Find the nearest *matching* stairs on the new level.
    //
    // Important: when the player uses STAIRS_DOWN, the destination should be
    // a STAIRS_UP tile (and vice-versa). The previous implementation searched
    // for either stair type and picked the closest; on levels that contain
    // both STAIRS_UP and STAIRS_DOWN tiles this can place the player onto a
    // STAIRS_DOWN tile after descending, causing them to immediately descend
    // again (or at least land on the wrong staircase).
    //
    // We infer which type to search for based on whether the level index
    // increased or decreased.
    const i32 old_idx = (i32)(old_level - levels);
    const i32 new_idx = (i32)(new_level - levels);
    const u8 target_stairs = (new_idx < old_idx) ? STAIRS_UP_TILE : STAIRS_DOWN_TILE;
    u8 best_x = 0;
    u8 best_y = 0;
    u32 best_dist = 0xffffffff;

    for(u32 y = 0; y < LEVEL_H; y++) {
        for(u32 x = 0; x < LEVEL_W; x++) {
            u8 tile = new_level->tiles[x + y * LEVEL_W];
            if(tile != target_stairs)
                continue;

            u32 dx = (x > old_xt) ? (x - old_xt) : (old_xt - x);
            u32 dy = (y > old_yt) ? (y - old_yt) : (old_yt - y);
            u32 dist = dx + dy;
            if(dist < best_dist) {
                best_dist = dist;
                best_x = x;
                best_y = y;
            }
        }
    }

    if(best_dist != 0xffffffff) {
        new_player->x = (best_x << 4) + 8;
        new_player->y = (best_y << 4) + 8;
        return;
    }

    // Special-case: the skyblock top level (index 3) intentionally has no
    // automatically-generated STAIRS_DOWN tiles, but level 2 can contain
    // STAIRS_UP tiles that lead back to the top (see generate_random_stairs_up_level2).
    // If we can't find a matching staircase when arriving on the top level,
    // place the player safely on the spawn island.
    if(new_idx == 3) {
        new_player->x = (TOP_LEVEL_SPAWN_XT << 4) + 8;
        new_player->y = (TOP_LEVEL_SPAWN_YT << 4) + 8;
        return;
    }

    // Fallback behaviour: if no matching stairs are present, align within the
    // same tile position as before.
    new_player->x = (old_player_x & 0xfff0) + 8;
    new_player->y = (old_player_y & 0xfff0) + 8;
}

static void game_init(u8 flags) {
    if(flags & 2) {
        struct Level *old_level = level;
        level = &levels[current_level];

        // move the player to the new level
        if(old_level && !(flags & 4))
            game_move_player(old_level, level);

        level_load(level);

        interrupt_wait(IRQ_VBLANK);
        screen_update_level_specific();
    }

    should_clear = true;
}

IWRAM_SECTION
static void game_tick(void) {
    if(scene_death_timer > 0) {
        scene_death_timer--;
        if(scene_death_timer == 0)
            set_scene(&scene_death, 1);
    }

    if(scene_win_timer > 0) {
        scene_win_timer--;
        if(scene_win_timer == 0)
            set_scene(&scene_win, 1);
    }

    level_tick(level);
}

static inline void clear_screen(void) {
    if(!should_clear)
        return;

    // clear level area (fully transparent)
    for(u32 y = 0; y < 18; y++)
        for(u32 x = 0; x < 30; x++)
            BG3_TILEMAP[x + y * 32] = 0;

    // clear status bar (black)
    for(u32 y = 18; y < 20; y++)
        for(u32 x = 0; x < 30; x++)
            BG3_TILEMAP[x + y * 32] = 32;

    should_clear = false;
}

static inline u16 get_player_hp(void) {
    struct entity_Data *player = &level->entities[0];
    if(player->type < ENTITY_TYPES) {
        struct mob_Data *mob_data = (struct mob_Data *) &player->data;

        return mob_data->hp;
    }
    return 0;
}

static inline void draw_status_bar(void) {
    u16 player_hp = get_player_hp();

    // draw hp and stamina
    for(u32 i = 0; i < 10; i++) {
        BG3_TILEMAP[i + 18 * 32] = (100 + (player_hp <= i))      | 10 << 12;
        BG3_TILEMAP[i + 19 * 32] = (102 + (player_stamina <= i)) | 10 << 12;
    }

    // set stamina blinking color
    {
        u16 color = 0x0cc6;
        if(player_stamina_recharge_delay != 0 &&
           (player_stamina_recharge_delay & 4) == 0) {
            color = 0x7bde;
        }
        screen_set_bg_palette_color(10, 12, color);
    }

    // clear active item area
    for(u32 x = 20; x < 30; x++)
        BG3_TILEMAP[x + 18 * 32] = 32;

    // draw active item
    if(player_active_item.type < ITEM_TYPES) {
        // copy item palette
        const struct Item *item = ITEM_S(&player_active_item);
        screen_load_active_item_palette(item->palette);

        item_draw_icon(&player_active_item, 20, 18, true);
        item_write(&player_active_item, 0, 21, 18);
    }
}

IWRAM_SECTION
static void game_draw(void) {
    clear_screen();
    level_draw(level);
    draw_status_bar();
}

const struct Scene scene_game = {
    .init = game_init,

    .tick = game_tick,
    .draw = game_draw
};
