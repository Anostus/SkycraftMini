/*
 * new_tiles.h
 *
 * This header defines the base tile indices for the dynamically
 * generated tree and sapling tiles used by the skyblock resource
 * trees. The indices correspond to locations in background
 * charblock 0 where the new tile graphics are written during
 * screen_init().
 *
 * Each resource variant gets:
 *   - 6 tree tiles: clones of the base tree adjacency tiles 34–39
 *   - 16 sapling tiles: clones of the base sapling tiles 56–71
 *
 * Total per variant: 22 tiles.
 *
 * This project also generates additional background tiles at runtime for
 * wood-themed blocks:
 *   - 1 wood plank texture (recoloured farmland)
 *   - 16 wood wall tiles (recoloured rock connectivity tiles)
 *
 * The ranges below live near the end of charblock 0 (0–511 tiles), well
 * beyond the base level tileset, to avoid collisions.
 */

#ifndef MINICRAFT_NEW_TILES_H
#define MINICRAFT_NEW_TILES_H

/* 6 tree tiles (src 34–39) + 16 sapling tiles (src 56–71) */
#define RESOURCE_TREE_TILES_PER_VARIANT     (6)
#define RESOURCE_SAPLING_TILES_PER_VARIANT  (16)
#define RESOURCE_TILES_PER_VARIANT          (RESOURCE_TREE_TILES_PER_VARIANT + RESOURCE_SAPLING_TILES_PER_VARIANT)

/* Dirt resource tree */
#define DIRT_TREE_TILE_BASE      (380)
#define DIRT_SAPLING_TILE_BASE   (DIRT_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/* Stone resource tree */
#define STONE_TREE_TILE_BASE     (DIRT_TREE_TILE_BASE + 1 * RESOURCE_TILES_PER_VARIANT)
#define STONE_SAPLING_TILE_BASE  (STONE_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/* Sand resource tree */
#define SAND_TREE_TILE_BASE      (DIRT_TREE_TILE_BASE + 2 * RESOURCE_TILES_PER_VARIANT)
#define SAND_SAPLING_TILE_BASE   (SAND_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/* Iron resource tree */
#define IRON_TREE_TILE_BASE      (DIRT_TREE_TILE_BASE + 3 * RESOURCE_TILES_PER_VARIANT)
#define IRON_SAPLING_TILE_BASE   (IRON_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/* Gold resource tree */
#define GOLD_TREE_TILE_BASE      (DIRT_TREE_TILE_BASE + 4 * RESOURCE_TILES_PER_VARIANT)
#define GOLD_SAPLING_TILE_BASE   (GOLD_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/* Gem resource tree */
#define GEM_TREE_TILE_BASE       (DIRT_TREE_TILE_BASE + 5 * RESOURCE_TILES_PER_VARIANT)
#define GEM_SAPLING_TILE_BASE    (GEM_TREE_TILE_BASE + RESOURCE_TREE_TILES_PER_VARIANT)

/*
 * Wood tiles
 *
 * These tiles are generated at runtime by cloning and recolouring existing
 * tiles with masks (see screen.c):
 *  - Wood plank: based on farmland tile 72, with brown indices mapped to
 *    sand-yellow indices, and drawn with the sand palette (palette 1).
 *  - Wood wall: based on the rock connectivity tile set (0–3, 12–23), with
 *    interior greys mapped to sand yellows while preserving the outline.
 */
#define WOOD_PLANK_TILE_GFX      (360)
#define WOOD_WALL_TILE_GFX_BASE  (361)
#define WOOD_WALL_TILE_GFX_COUNT (16)

#endif /* MINICRAFT_NEW_TILES_H */
