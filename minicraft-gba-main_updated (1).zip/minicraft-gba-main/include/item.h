/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#ifndef MINICRAFT_ITEM
#define MINICRAFT_ITEM

#include "minicraft.h"

// Increase item type count to account for new stair items as well as the
// additional skyblock progression items introduced below.  We extend
// the enumeration to accommodate a new tool (the "Time" item) and
// several acorn variants used to grow different resource trees.  An
// extra item type has been added for the Dirt Acorn which plants
// a dirt tree that produces dirt.
#define ITEM_TYPES (43)

#define WOOD_ITEM       (0)
#define STONE_ITEM      (1)
#define GLASS_ITEM      (2)
#define WHEAT_ITEM      (3)
#define SLIME_ITEM      (4)
#define CLOTH_ITEM      (5)
#define COAL_ITEM       (6)
#define IRON_ORE_ITEM   (7)
#define GOLD_ORE_ITEM   (8)
#define IRON_INGOT_ITEM (9)
#define GOLD_INGOT_ITEM (10)
#define GEM_ITEM        (11)

#define FLOWER_ITEM (12)
#define SEEDS_ITEM  (13)
#define ACORN_ITEM  (14)
#define CACTUS_ITEM (15)
#define DIRT_ITEM   (16)
#define SAND_ITEM   (17)
#define CLOUD_ITEM  (18)

#define APPLE_ITEM (19)
#define BREAD_ITEM (20)

#define WORKBENCH_ITEM (21)
#define FURNACE_ITEM   (22)
#define OVEN_ITEM      (23)
#define ANVIL_ITEM     (24)
#define CHEST_ITEM     (25)
#define LANTERN_ITEM   (26)

#define POWERGLOVE_ITEM (27)

#define SWORD_ITEM  (28)
#define AXE_ITEM    (29)
#define PICK_ITEM   (30)
#define SHOVEL_ITEM (31)
#define HOE_ITEM    (32)

// New items for skyblock progression.  These are placeable stair items that
// allow the player to link levels vertically.  They come after the
// existing items so that previously defined indices remain unchanged.
#define STAIRS_DOWN_ITEM  (33)
#define STAIRS_UP_ITEM    (34)

// Additional items used by the skyblock variant.  A new tool called
// "Time" allows saplings to be accelerated without damaging entities.
// The existing ACORN_ITEM serves as the dirt acorn.  Each of the
// following acorn variants can be planted to grow a corresponding
// resource tree.  They are appended after the stairs items to keep
// earlier indices stable.
#define TIME_ITEM         (35)
#define STONE_ACORN_ITEM  (36)
#define SAND_ACORN_ITEM   (37)
#define IRON_ACORN_ITEM   (38)
#define GOLD_ACORN_ITEM   (39)
#define GEM_ACORN_ITEM    (40)

// Dirt Acorn.  Plants a dirt tree that yields dirt when felled.  This
// item is separate from the base acorn (ACORN_ITEM) which grows a
// normal tree.
// Dirt Acorn.  Plants a dirt tree that yields dirt when felled.  This
// item is separate from the base acorn (ACORN_ITEM) which grows a
// normal tree.
#define DIRT_ACORN_ITEM   (41)

// Basic Crafting Table.  A simplified crafting station that allows
// the player to craft a full workbench from four wood.  This item
// appears at the end of the item list so that existing indices remain
// unchanged.  It is treated as a furniture item via custom logic in
// entity_add_furniture.
#define BASIC_WORKBENCH_ITEM (42)

#define ITEMCLASS_MATERIAL   (0)
#define ITEMCLASS_PLACEABLE  (1)
#define ITEMCLASS_FOOD       (2)
#define ITEMCLASS_FURNITURE  (3)
#define ITEMCLASS_POWERGLOVE (4)
#define ITEMCLASS_TOOL       (5)

struct Item {
    u8 class;
    char *name;
    u8 palette;

    union {
        // ITEMCLASS_PLACEABLE
        struct {
            u8 placed_tile;
            // List of tiles that this item can be placed onto.
            // 0xFF (-1) can be used as a sentinel to mark the end of the list.
            u8 placeable_on[4];
        };

        // ITEMCLASS_FOOD
        struct {
            u8 hp_gain;
        };

        // ITEMCLASS_FURNITURE
        struct {
            u8 furniture;
        };
    };
};

struct item_Data {
    u8 type;

    union {
        u16 count;
        u8 tool_level;
        u8 chest_id;
    };
};

#define ITEM_S(data)\
    (&item_list[(data)->type])

extern const struct Item item_list[ITEM_TYPES];

extern void item_write(struct item_Data *data, u8 palette, u32 x, u32 y);
extern void item_write_name(struct item_Data *data, u8 palette, u32 x, u32 y);
extern void item_draw_icon(struct item_Data *data, u32 x, u32 y, bool black_bg);

INLINE bool item_is_resource(u8 type) {
    const struct Item *item = &item_list[type];

    return item->class == ITEMCLASS_MATERIAL  ||
           item->class == ITEMCLASS_PLACEABLE ||
           item->class == ITEMCLASS_FOOD;
}

#endif // MINICRAFT_ITEM
