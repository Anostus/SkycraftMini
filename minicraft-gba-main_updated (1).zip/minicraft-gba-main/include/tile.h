/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#ifndef MINICRAFT_TILE
#define MINICRAFT_TILE

#include "minicraft.h"

#include "level.h"
#include "item.h"

// Increase tile type count to include additional resource tree and sapling
// variants introduced for the skyblock mode, plus a new wood plank tile
// that allows bridging over the void and water.  New tile IDs are
// appended after the existing ones to maintain compatibility.
#define TILE_TYPES (36)

#define GRASS_TILE          (0)
#define ROCK_TILE           (1)
#define LIQUID_TILE         (2)
#define FLOWER_TILE         (3)
#define TREE_TILE           (4)
#define DIRT_TILE           (5)
#define SAND_TILE           (6)
#define CACTUS_TILE         (7)
#define HOLE_TILE           (8)
#define TREE_SAPLING_TILE   (9)
#define CACTUS_SAPLING_TILE (10)
#define FARMLAND_TILE       (11)
#define WHEAT_TILE          (12)
#define STAIRS_DOWN_TILE    (13)
#define STAIRS_UP_TILE      (14)
#define INFINITE_FALL_TILE  (15)
#define CLOUD_TILE          (16)
#define HARD_ROCK_TILE      (17)
#define IRON_ORE_TILE       (18)
#define GOLD_ORE_TILE       (19)
#define GEM_ORE_TILE        (20)
#define CLOUD_CACTUS_TILE   (21)

// Additional tree tiles.  Each of these behaves like a standard tree
// but drops a different resource when felled.  The ordering here must
// match the initialization order in tile_list.
#define DIRT_TREE_TILE        (22)
#define STONE_TREE_TILE       (23)
#define SAND_TREE_TILE        (24)
#define IRON_TREE_TILE        (25)
#define GOLD_TREE_TILE        (26)
#define GEM_TREE_TILE         (27)

// Additional sapling tiles corresponding to the resource trees above.
#define DIRT_SAPLING_TILE     (28)
#define STONE_SAPLING_TILE    (29)
#define SAND_SAPLING_TILE     (30)
#define IRON_SAPLING_TILE     (31)
#define GOLD_SAPLING_TILE     (32)
#define GEM_SAPLING_TILE      (33)

// Wood plank tile used for building bridges.  This tile behaves like
// dirt but uses the wheat palette for its appearance.  It is added
// after the saplings to preserve enumeration order.
// Wood plank tile used for building bridges.  This tile behaves like
// dirt but uses the wheat palette for its appearance.  It is added
// after the saplings to preserve enumeration order.
#define WOOD_TILE           (34)

// Wood wall tile
//
// A solid block similar to natural rock but made of wood.  When
// destroyed it drops a single wood item instead of stone and is
// primarily damaged by axes rather than picks.  This tile is
// appended after the wood plank to maintain enumeration ordering.
#define WOOD_WALL_TILE      (35)

struct Tile {
    bool is_solid;
    u8 may_pass;

    u8 touch_damage;

    void (*stepped_on)(struct Level *level, u32 xt, u32 yt,
                       struct entity_Data *entity_data);

    void (*interact)(struct Level *level, u32 xt, u32 yt,
                     struct item_Data *item);

    struct {
        bool grass;
        bool sand;
        bool liquid;
    } connects_to;
};

extern const struct Tile tile_list[TILE_TYPES];

#endif // MINICRAFT_TILE
