/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#ifndef MINICRAFT_GENERATOR
#define MINICRAFT_GENERATOR

#include "minicraft.h"

#include "level.h"

// Fixed spawn and island location on the top level (level index 3)
#define TOP_LEVEL_SPAWN_XT (LEVEL_W / 2)
#define TOP_LEVEL_SPAWN_YT (LEVEL_H / 2)
#define TOP_LEVEL_TREE_XT  (TOP_LEVEL_SPAWN_XT - 1)
#define TOP_LEVEL_TREE_YT  (TOP_LEVEL_SPAWN_YT)


extern void generate_levels(void);

#endif // MINICRAFT_GENERATOR
