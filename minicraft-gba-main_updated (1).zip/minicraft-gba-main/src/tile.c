/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "tile.h"

#include "level.h"
#include "sound.h"
#include "entity.h"
#include "player.h"
#include "item.h"
#include "sound.h"

#define FSTEPPED_ON(name)\
    IWRAM_SECTION\
    static void name(struct Level *level, u32 xt, u32 yt,\
                     struct entity_Data *entity_data)

#define FINTERACT(name)\
    static void name(struct Level *level, u32 xt, u32 yt,\
                     struct item_Data *item)

#define GET_PUNCH_DAMAGE() (1 + random(3))


static inline bool player_inventory_has_item(u8 item_type) {
    for(u32 i = 0; i < player_inventory.size; i++) {
        if(player_inventory.items[i].type == item_type && player_inventory.items[i].count > 0)
            return true;
    }

    return false;
}

static inline u8 tree_acorn_drop_count(u8 acorn_item_type) {
    u8 count = random(4);

    if(count == 0 && !player_inventory_has_item(acorn_item_type))
        count = 1;

    return count;
}

// Grass
FINTERACT(grass_interact) {
    if(item->type == SHOVEL_ITEM) {
        if(player_pay_stamina(4 - item->tool_level)) {
            if(random(5) == 0)
                entity_add_item(level, xt, yt, SEEDS_ITEM, true);

            LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);

            SOUND_PLAY(sound_monster_hurt);
        }
    } else if(item->type == HOE_ITEM) {
        if(player_pay_stamina(4 - item->tool_level)) {
            LEVEL_SET_TILE(level, xt, yt, FARMLAND_TILE, 0);

            if(random(5) == 0)
                entity_add_item(level, xt, yt, SEEDS_ITEM, true);

            SOUND_PLAY(sound_monster_hurt);
        }
    }
}

// Rock
FINTERACT(rock_interact) {
    u8 dmg;
    if(item->type == PICK_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 50) {
        u8 count = 1 + random(4);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, STONE_ITEM, true);

        if(random(2))
            entity_add_item(level, xt, yt, COAL_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Flower
FINTERACT(flower_interact) {
    u8 count;
    if(item->type == SHOVEL_ITEM && player_pay_stamina(4 - item->tool_level))
        count = 2;
    else
        count = 1 + random(2);

    for(u32 i = 0; i < count; i++)
        entity_add_item(level, xt, yt, FLOWER_ITEM, true);

    LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
}

// Tree
FINTERACT(tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        count = tree_acorn_drop_count(ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// === Resource Tree Variants ===
// Each of the following interaction functions behaves similarly to
// tree_interact but drops an additional resource and variant-specific
// acorns when felled.  The functions are nearly identical aside from
// the resource and acorn item IDs used.

// Dirt Tree: drops wood, apples, dirt and dirt acorns
FINTERACT(dirt_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        // Always drop dirt when a dirt tree is cut down
        entity_add_item(level, xt, yt, DIRT_ITEM, true);

        // Drop dirt acorns (DIRT_ACORN_ITEM).  These are distinct from
        // the base acorn (ACORN_ITEM) and grow dirt trees when planted.
        count = tree_acorn_drop_count(DIRT_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, DIRT_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Stone Tree: drops wood, apples, stone and stone acorns
FINTERACT(stone_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        // Stone resource
        entity_add_item(level, xt, yt, STONE_ITEM, true);

        // Stone acorns
        count = tree_acorn_drop_count(STONE_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, STONE_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Sand Tree: drops wood, apples, sand and sand acorns
FINTERACT(sand_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        entity_add_item(level, xt, yt, SAND_ITEM, true);

        count = tree_acorn_drop_count(SAND_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, SAND_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Iron Tree: drops wood, apples, iron ore and iron acorns
FINTERACT(iron_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        entity_add_item(level, xt, yt, IRON_ORE_ITEM, true);

        count = tree_acorn_drop_count(IRON_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, IRON_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Gold Tree: drops wood, apples, gold ore and gold acorns
FINTERACT(gold_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        entity_add_item(level, xt, yt, GOLD_ORE_ITEM, true);

        count = tree_acorn_drop_count(GOLD_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, GOLD_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Gem Tree: drops wood, apples, gem ore and gem acorns
FINTERACT(gem_tree_interact) {
    u8 dmg;
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    if(random(10) == 0)
        entity_add_item(level, xt, yt, APPLE_ITEM, true);

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 20) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

        entity_add_item(level, xt, yt, GEM_ITEM, true);

        count = tree_acorn_drop_count(GEM_ACORN_ITEM);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, GEM_ACORN_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// === Variant Sapling interactions ===
// These functions allow saplings to be accelerated using the Time item.  If
// another item is used, the sapling is uprooted and replaced with grass.

static inline void sapling_accelerate(struct Level *level, u32 xt, u32 yt,
                                      u8 target_tree_tile, struct item_Data *item) {
    if(item->type == TIME_ITEM) {
        // Increase growth by 25 ticks per use
        u8 age = LEVEL_GET_DATA(level, xt, yt);
        if(age + 25 >= 100) {
            LEVEL_SET_TILE(level, xt, yt, target_tree_tile, 0);
        } else {
            LEVEL_SET_DATA(level, xt, yt, age + 25);
        }
        // play the same sound as chopping a tree
        SOUND_PLAY(sound_monster_hurt);
    } else {
        // uproot the sapling
        LEVEL_SET_TILE(level, xt, yt, GRASS_TILE, 0);
    }
}

FINTERACT(dirt_sapling_interact) {
    sapling_accelerate(level, xt, yt, DIRT_TREE_TILE, item);
}

FINTERACT(stone_sapling_interact) {
    sapling_accelerate(level, xt, yt, STONE_TREE_TILE, item);
}

FINTERACT(sand_sapling_interact) {
    sapling_accelerate(level, xt, yt, SAND_TREE_TILE, item);
}

FINTERACT(iron_sapling_interact) {
    sapling_accelerate(level, xt, yt, IRON_TREE_TILE, item);
}

FINTERACT(gold_sapling_interact) {
    sapling_accelerate(level, xt, yt, GOLD_TREE_TILE, item);
}

FINTERACT(gem_sapling_interact) {
    sapling_accelerate(level, xt, yt, GEM_TREE_TILE, item);
}

// Wood Plank
//
// This tile represents a wooden plank used to bridge gaps.  When
// interacted with using an axe, it drops a wood item and the
// underlying space reverts to a hole (void).  Other tools have no
// effect.
FINTERACT(wood_interact) {
    // Only axes can break wood planks.  Other tools do nothing.
    if(item->type == AXE_ITEM) {
        if(player_pay_stamina(4 - item->tool_level)) {
            // Drop a single wood item when the plank is chopped.
            entity_add_item(level, xt, yt, WOOD_ITEM, true);

            // Remove the plank and leave an infinite fall tile instead
            // of a hole.  This better matches the behaviour of
            // bridging over the void so that chopped planks return
            // to void rather than a hole tile.
            LEVEL_SET_TILE(level, xt, yt, INFINITE_FALL_TILE, 0);

            SOUND_PLAY(sound_monster_hurt);
        }
    }
}

// Wood Wall
//
// A solid wood block analogous to the rock tile but made of wood.
// When interacted with using an axe, it drops a single wood item and
// turns into dirt.  Picks and punches deal minimal damage, whereas
// axes deal significantly more damage.  The behaviour mirrors the
// rock tile but swaps the effective tool and drop.
FINTERACT(wood_wall_interact) {
    u8 dmg;
    // Axes are effective on wood walls.  Other tools/punches deal
    // significantly less damage.
    if(item->type == AXE_ITEM && player_pay_stamina(4 - item->tool_level))
        dmg = 10 + item->tool_level * 5 + random(10);
    else
        dmg = GET_PUNCH_DAMAGE();

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    // Wood walls have the same total durability as rock walls
    if(damage >= 50) {
        // Drop exactly one wood item on destruction.
        entity_add_item(level, xt, yt, WOOD_ITEM, true);

        // Replace with a wooden plank once broken.  Leaving dirt here
        // would make dismantling wood walls yield dirt, which is
        // unintuitive.  Wood walls should revert back to planks on
        // destruction.
        LEVEL_SET_TILE(level, xt, yt, WOOD_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    // Visual feedback identical to rock destruction
    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Dirt
FINTERACT(dirt_interact) {
    if(item->type == SHOVEL_ITEM) {
        if(player_pay_stamina(4 - item->tool_level)) {
            entity_add_item(level, xt, yt, DIRT_ITEM, true);

            LEVEL_SET_TILE(level, xt, yt, HOLE_TILE, 0);

            SOUND_PLAY(sound_monster_hurt);
        }
    } else if(item->type == HOE_ITEM) {
        if(player_pay_stamina(4 - item->tool_level)) {
            LEVEL_SET_TILE(level, xt, yt, FARMLAND_TILE, 0);

            SOUND_PLAY(sound_monster_hurt);
        }
    }
}

// Sand
FSTEPPED_ON(sand_stepped_on) {
    u8 etype = entity_data->type;
    if(etype == ZOMBIE_ENTITY ||
       etype == SLIME_ENTITY ||
       etype == PLAYER_ENTITY) {
        LEVEL_SET_DATA(level, xt, yt, 10);
    }
}

FINTERACT(sand_interact) {
    if(item->type == SHOVEL_ITEM && player_pay_stamina(4 - item->tool_level)) {
        entity_add_item(level, xt, yt, SAND_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);

        // no sound after digging sand
        // might be a bug in the original game
    }
}

// Cactus
FINTERACT(cactus_interact) {
    u8 dmg = GET_PUNCH_DAMAGE();

    u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
    if(damage >= 10) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, CACTUS_ITEM, true);

        LEVEL_SET_TILE(level, xt, yt, SAND_TILE, 0);
    } else {
        LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Tree Sapling
/*
 * Base tree sapling interaction.  In the vanilla game, using any item on
 * a tree sapling immediately uproots it.  For the skyblock mod we want
 * the Time tool to accelerate the sapling’s growth just like the
 * resource saplings do.  Reuse the sapling_accelerate helper to
 * increment the age when Time is used, otherwise uproot to grass.
 */
FINTERACT(tree_sapling_interact) {
    // Advance growth when using the Time item.  The helper will check
    // the item type and either increment the age or uproot.
    sapling_accelerate(level, xt, yt, TREE_TILE, item);
}

// Cactus Sapling
FINTERACT(cactus_sapling_interact) {
    LEVEL_SET_TILE(level, xt, yt, SAND_TILE, 0);
}

// Farmland
FSTEPPED_ON(farmland_stepped_on) {
    if(random(60) != 0)
        return;

    if(LEVEL_GET_DATA(level, xt, yt) >= 5)
        LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
}

FINTERACT(farmland_interact) {
    if(item->type == SHOVEL_ITEM && player_pay_stamina(4 - item->tool_level))
        LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
}

// Wheat
static inline void wheat_harvest(struct Level *level, u32 xt, u32 yt) {
    if(random(2))
        entity_add_item(level, xt, yt, SEEDS_ITEM, true);

    u8 age = LEVEL_GET_DATA(level, xt, yt);
    if(age >= 40) {
        u8 count;
        if(age == 50)
            count = 2 + random(3);
        else
            count = 1 + random(2);

        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, WHEAT_ITEM, true);
    }

    LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
}

FSTEPPED_ON(wheat_stepped_on) {
    if(random(60) != 0)
        return;

    if(LEVEL_GET_DATA(level, xt, yt) >= 2)
        wheat_harvest(level, xt, yt);
}

FINTERACT(wheat_interact) {
    if(item->type == SHOVEL_ITEM && player_pay_stamina(4 - item->tool_level))
        LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
    else
        wheat_harvest(level, xt, yt);
}

// Cloud
FINTERACT(cloud_interact) {
    if(item->type == SHOVEL_ITEM && player_pay_stamina(5)) {
        u8 count = 1 + random(2);
        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, CLOUD_ITEM, true);
    }
}

// Hard Rock
FINTERACT(hard_rock_interact) {
    u8 dmg = 0;
    if(item->type == PICK_ITEM && item->tool_level == 4) {
        dmg = 30 + random(10);

        u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
        if(damage >= 200) {
            u8 count = 1 + random(4);
            for(u32 i = 0; i < count; i++)
                entity_add_item(level, xt, yt, STONE_ITEM, true);

            if(random(2))
                entity_add_item(level, xt, yt, COAL_ITEM, true);

            LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);
        } else {
            LEVEL_SET_DATA(level, xt, yt, damage);
        }
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Ores
FINTERACT(ore_interact) {
    u8 dmg = 0;
    if(item->type == PICK_ITEM && player_pay_stamina(6 - item->tool_level)) {
        dmg = 1;

        u8 count = random(2);
        u8 tile = LEVEL_GET_TILE(level, xt, yt);
        u8 item_to_drop = ((tile == IRON_ORE_TILE) * IRON_ORE_ITEM) |
                          ((tile == GOLD_ORE_TILE) * GOLD_ORE_ITEM) |
                          ((tile == GEM_ORE_TILE)  * GEM_ITEM);

        u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
        if(damage >= 3 + random(10)) {
            LEVEL_SET_TILE(level, xt, yt, DIRT_TILE, 0);

            count += 2;
        } else {
            LEVEL_SET_DATA(level, xt, yt, damage);
        }

        for(u32 i = 0; i < count; i++)
            entity_add_item(level, xt, yt, item_to_drop, true);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

// Cloud Cactus
FINTERACT(cloud_cactus_interact) {
    u8 dmg = 0;
    if(item->type == PICK_ITEM && player_pay_stamina(6 - item->tool_level)) {
        dmg = 1;

        u8 damage = LEVEL_GET_DATA(level, xt, yt) + dmg;
        if(damage >= 10)
            LEVEL_SET_TILE(level, xt, yt, CLOUD_TILE, 0);
        else
            LEVEL_SET_DATA(level, xt, yt, damage);
    }

    entity_add_smash_particle(level, xt, yt);
    entity_add_text_particle(level, (xt << 4) + 8, (yt << 4) + 8, dmg, 0);
}

IWRAM_RODATA_SECTION
const struct Tile tile_list[TILE_TYPES] = {
    // Grass
    {
        .connects_to = {
            .grass = true
        },

        .interact = grass_interact
    },

    // Rock
    {
        .is_solid = true,
        .may_pass = -1,

        .interact = rock_interact
    },

    // Liquid
    {
        .connects_to = {
            .sand   = true,
            .liquid = true
        },

        .is_solid = true,
        .may_pass = PLAYER_ENTITY
    },

    // Flower
    {
        .connects_to = {
            .grass = true
        },

        .interact = flower_interact
    },

    // Tree
    {
        .connects_to = {
            .grass = true
        },

        .is_solid = true,
        .may_pass = -1,

        .interact = tree_interact
    },

    // Dirt
    {
        .interact = dirt_interact
    },

    // Sand
    {
        .connects_to = {
            .sand = true
        },

        .stepped_on = sand_stepped_on,

        .interact = sand_interact
    },

    // Cactus
    {
        .connects_to = {
            .sand = true
        },

        .is_solid = true,
        .may_pass = -1,

        .touch_damage = 1,

        .interact = cactus_interact
    },

    // Hole
    {
        .connects_to = {
            .sand   = true,
            .liquid = true,
        },

        .is_solid = true,
        .may_pass = PLAYER_ENTITY
    },

    // Tree Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = tree_sapling_interact
    },

    // Cactus Sapling
    {
        .connects_to = {
            .sand = true
        },

        .interact = cactus_sapling_interact
    },

    // Farmland
    {
        .stepped_on = farmland_stepped_on,

        .interact = farmland_interact
    },

    // Wheat
    {
        .stepped_on = wheat_stepped_on,

        .interact = wheat_interact
    },

    // Stairs Down
    { 0 },

    // Stairs Up
    { 0 },

    // Infinite Fall
    {
        .is_solid = true,
        .may_pass = AIR_WIZARD_ENTITY
    },

    // Cloud
    {
        .interact = cloud_interact
    },

    // Hard Rock
    {
        .is_solid = true,
        .may_pass = -1,

        .interact = hard_rock_interact
    },

    // Iron Ore
    {
        .is_solid = true,
        .may_pass = -1,

        .touch_damage = 3,

        .interact = ore_interact
    },

    // Gold Ore
    {
        .is_solid = true,
        .may_pass = -1,

        .touch_damage = 3,

        .interact = ore_interact
    },

    // Gem Ore
    {
        .is_solid = true,
        .may_pass = -1,

        .touch_damage = 3,

        .interact = ore_interact
    },

    // Cloud Cactus
    {
        .is_solid = true,
        .may_pass = AIR_WIZARD_ENTITY,

        .touch_damage = 3,

        .interact = cloud_cactus_interact
    },

    // === Resource Trees ===

    // Dirt Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = dirt_tree_interact
    },

    // Stone Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = stone_tree_interact
    },

    // Sand Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = sand_tree_interact
    },

    // Iron Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = iron_tree_interact
    },

    // Gold Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = gold_tree_interact
    },

    // Gem Tree
    {
        .connects_to = {
            .grass = true
        },
        .is_solid = true,
        .may_pass = -1,

        .interact = gem_tree_interact
    },

    // === Resource Saplings ===

    // Dirt Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = dirt_sapling_interact
    },

    // Stone Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = stone_sapling_interact
    },

    // Sand Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = sand_sapling_interact
    },

    // Iron Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = iron_sapling_interact
    },

    // Gold Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = gold_sapling_interact
    },

    // Gem Sapling
    {
        .connects_to = {
            .grass = true
        },

        .interact = gem_sapling_interact
    },

    // Wood Plank
    //
    // A wooden plank tile for bridging the void or water.  It connects
    // visually to both grass and liquid tiles to produce smooth edges.
    {
        .connects_to = {
            .grass = true,
            .liquid = true
        },

        .interact = wood_interact
    }

    ,

    // Wood Wall
    //
    // Solid block of wood.  Functions like rock but with wood-themed
    // interactions.  Axes break it faster than other tools and it
    // drops a single wood when destroyed.  Does not connect to other
    // materials visually.
    {
        .is_solid = true,
        .may_pass = -1,

        .interact = wood_wall_interact
    }
};
