/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "tile.h"

#include "level.h"

#define FTICK(name)\
    static inline void name(struct Level *level, u32 xt, u32 yt)

FTICK(damage_recover_tick) {
    u8 damage = LEVEL_GET_DATA(level, xt, yt);
    if(damage != 0)
        LEVEL_SET_DATA(level, xt, yt, damage - 1);
}

FTICK(grass_tick) {
    if(random(40) != 0)
        return;

    i32 xn = xt;
    i32 yn = yt;

    if(random(2))
        xn += random(2) * 2 - 1;
    else
        yn += random(2) * 2 - 1;

    if(LEVEL_GET_TILE(level, xn, yn) == DIRT_TILE)
        LEVEL_SET_TILE(level, xn, yn, GRASS_TILE, 0);
}

FTICK(liquid_tick) {
    i32 xn = xt;
    i32 yn = yt;

    if(random(2))
        xn += random(2) * 2 - 1;
    else
        yn += random(2) * 2 - 1;

    if(LEVEL_GET_TILE(level, xn, yn) == HOLE_TILE)
        LEVEL_SET_TILE(level, xn, yn, LIQUID_TILE, 0);
}

FTICK(tree_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;

    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

// Skyblock: additional sapling tick functions for resource saplings.  Each
// resource sapling behaves like the base tree sapling but grows into its
// corresponding resource tree tile when its age reaches 100.  Without
// these functions the saplings would never advance beyond the sapling
// stage.  The growth timing (100 ticks) matches the vanilla tree
// behaviour so that using the Time tool (which advances age by 25)
// requires four hits to fully grow the tree.
FTICK(dirt_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, DIRT_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(stone_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, STONE_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(sand_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, SAND_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(iron_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, IRON_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(gold_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, GOLD_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(gem_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;
    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, GEM_TREE_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(cactus_sapling_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt) + 1;

    if(age > 100)
        LEVEL_SET_TILE(level, xt, yt, CACTUS_TILE, 0);
    else
        LEVEL_SET_DATA(level, xt, yt, age);
}

FTICK(farmland_tick) {
    u8 age = LEVEL_GET_DATA(level, xt, yt);
    if(age < 5)
        LEVEL_SET_DATA(level, xt, yt, age + 1);
}

FTICK(wheat_tick) {
    if(random(2))
        return;

    u8 age = LEVEL_GET_DATA(level, xt, yt);
    if(age < 50)
        LEVEL_SET_DATA(level, xt, yt, age + 1);
}

#define CALL(function)\
    function(level, xt, yt)

static inline void tick_tile(struct Level *level, u32 xt, u32 yt) {
    switch(LEVEL_GET_TILE(level, xt, yt)) {
        case ROCK_TILE:
        case TREE_TILE:
        case SAND_TILE:
        case CACTUS_TILE:
        case HARD_ROCK_TILE:
            CALL(damage_recover_tick);
            break;

        // Apply damage recovery tick to all resource tree variants.  Without
        // this the trees would never heal from chop damage, making them
        // effectively unbreakable after the first hit.  Including them
        // here preserves the original tree behaviour.
        case DIRT_TREE_TILE:
        case STONE_TREE_TILE:
        case SAND_TREE_TILE:
        case IRON_TREE_TILE:
        case GOLD_TREE_TILE:
        case GEM_TREE_TILE:
            CALL(damage_recover_tick);
            break;

        case GRASS_TILE:
        case FLOWER_TILE:
            CALL(grass_tick);
            break;

        case LIQUID_TILE:
            CALL(liquid_tick);
            break;

        case TREE_SAPLING_TILE:
            CALL(tree_sapling_tick);
            break;

        // Tick functions for resource saplings.  Each case calls its
        // specific tick function defined above.  When these saplings age
        // past 100 ticks they turn into their corresponding resource tree.
        case DIRT_SAPLING_TILE:
            CALL(dirt_sapling_tick);
            break;
        case STONE_SAPLING_TILE:
            CALL(stone_sapling_tick);
            break;
        case SAND_SAPLING_TILE:
            CALL(sand_sapling_tick);
            break;
        case IRON_SAPLING_TILE:
            CALL(iron_sapling_tick);
            break;
        case GOLD_SAPLING_TILE:
            CALL(gold_sapling_tick);
            break;
        case GEM_SAPLING_TILE:
            CALL(gem_sapling_tick);
            break;

        case CACTUS_SAPLING_TILE:
            CALL(cactus_sapling_tick);
            break;

        case FARMLAND_TILE:
            CALL(farmland_tick);
            break;

        case WHEAT_TILE:
            CALL(wheat_tick);
            break;
    }
}

#undef CALL
