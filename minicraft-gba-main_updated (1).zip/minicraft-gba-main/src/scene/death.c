/* Copyright 2022, 2024 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "scene.h"

#include "screen.h"
#include "options.h"
#include "generator.h"
#include "level.h"
#include "entity.h"
#include "tile.h"
#include "sound.h"

static u8 death_time;

THUMB
static void death_init(u8 flags) {
    death_time = 0;
}

static inline void get_spawn_location(struct Level *level,
                                      u32 *spawn_x, u32 *spawn_y) {
    (void) level;

    // Fixed spawn on the tiny top-level island.
    *spawn_x = TOP_LEVEL_SPAWN_XT;
    *spawn_y = TOP_LEVEL_SPAWN_YT;
}

static inline void respawn(void) {
    struct Level *level = &levels[3];
    current_level = 3;

    // remove all hostile entities from the level
    for(u32 i = 1; i < ENTITY_LIMIT; i++) {
        struct entity_Data *data = &level->entities[i];
        if(data->type == ZOMBIE_ENTITY || data->type == SLIME_ENTITY)
            data->type = -1;
    }

    // choose a new spawn position
    u32 spawn_x = 0, spawn_y = 0;
    get_spawn_location(level, &spawn_x, &spawn_y);

    entity_add_player(
        level,
        spawn_x, spawn_y,
        !options.keep_inventory
    );
}

THUMB
static void death_tick(void) {
    death_time++;
    if(death_time > 60) {
        if(input_press(KEY_A) || input_press(KEY_B)) {
            SOUND_PLAY(sound_start);
            respawn();
            set_scene(&scene_game, 7);
        }
    }
}

THUMB
static void death_draw(void) {
    const u8 death_x = 5;
    const u8 death_y = 5;
    const u8 death_w = 20;
    const u8 death_h = 7;

    screen_draw_frame("", death_x, death_y, death_w, death_h);
    screen_write("YOU DIED! AWW!", 6, death_x + 1, death_y + 1);

    screen_write("TIME:", 6, death_x + 1, death_y + 2);
    screen_write_time(gametime, 10, death_x + 6, death_y + 2);

    screen_write("SCORE:", 6, death_x + 1, death_y + 3);
    SCREEN_WRITE_NUMBER(score, 10, 10, false, 10, death_x + 7, death_y + 3);

    screen_write("PRESS A TO RESPAWN", 8, death_x + 1, death_y + 5);
}

const struct Scene scene_death = {
    .init = death_init,

    .tick = death_tick,
    .draw = death_draw
};
