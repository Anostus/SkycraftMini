/* Copyright 2022 Vulcalien
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#include "crafting.h"

#include "inventory.h"
#include "item.h"
#include "furniture.h"

const struct crafting_Recipe workbench_recipes[WORKBENCH_RECIPES] = {
    // Furniture

    // Lantern
    {
        .required.items = { WOOD_ITEM, SLIME_ITEM, GLASS_ITEM },
        .required.count = { 5,         10,         4          },

        .result = LANTERN_ITEM
    },

    // Oven
    // Changed to craft from dirt instead of stone to allow early progression
    {
        .required.items = { DIRT_ITEM },
        .required.count = { 15 },

        .result = OVEN_ITEM
    },

    // Furnace
    // Changed to craft from dirt instead of stone to allow early progression
    {
        .required.items = { DIRT_ITEM },
        .required.count = { 20 },

        .result = FURNACE_ITEM
    },

    // Workbench
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 20 },

        .result = WORKBENCH_ITEM
    },

    // Chest
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 20 },

        .result = CHEST_ITEM
    },

    // Anvil
    {
        .required.items = { IRON_INGOT_ITEM },
        .required.count = { 5 },

        .result = ANVIL_ITEM
    },

    // Wood Tools

    // Wood Sword
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 5 },

        .result = SWORD_ITEM,
        .tool_level = 0
    },

    // Wood Axe
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 5 },

        .result = AXE_ITEM,
        .tool_level = 0
    },

    // Wood Hoe
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 5 },

        .result = HOE_ITEM,
        .tool_level = 0
    },

    // Wood Pick
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 5 },

        .result = PICK_ITEM,
        .tool_level = 0
    },

    // Wood Shovel
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 5 },

        .result = SHOVEL_ITEM,
        .tool_level = 0
    },

    // Stone Tools

    // Stone Sword
    {
        .required.items = { WOOD_ITEM, STONE_ITEM },
        .required.count = { 5,         5          },

        .result = SWORD_ITEM,
        .tool_level = 1
    },

    // Stone Axe
    {
        .required.items = { WOOD_ITEM, STONE_ITEM },
        .required.count = { 5,         5          },

        .result = AXE_ITEM,
        .tool_level = 1
    },

    // Stone Hoe
    {
        .required.items = { WOOD_ITEM, STONE_ITEM },
        .required.count = { 5,         5          },

        .result = HOE_ITEM,
        .tool_level = 1
    },

    // Stone Pick
    {
        .required.items = { WOOD_ITEM, STONE_ITEM },
        .required.count = { 5,         5          },

        .result = PICK_ITEM,
        .tool_level = 1
    },

    // Stone Shovel
    {
        .required.items = { WOOD_ITEM, STONE_ITEM },
        .required.count = { 5,         5          },

        .result = SHOVEL_ITEM,
        .tool_level = 1
    },

    // === New Workbench Recipes for Skyblock Progression ===
    /*
     * The recipes to craft sand, cloth and slime have been removed.
     * Players must now obtain these materials through other means
     * rather than crafting them directly at a workbench.  Removing
     * these entries reduces the total number of workbench recipes
     * accordingly.
     */

    // Stairs Down: build passage down using iron
    {
        .required.items = { IRON_INGOT_ITEM },
        .required.count = { 4 },

        .result = STAIRS_DOWN_ITEM
    },

    // Stairs Up: build passage up using gold
    {
        .required.items = { GOLD_INGOT_ITEM },
        .required.count = { 4 },

        .result = STAIRS_UP_ITEM
    }

    ,

    // === Skyblock Workbench Recipes ===

    // Stone Acorn: craft from a dirt acorn and coal
    {
        .required.items = { DIRT_ACORN_ITEM, COAL_ITEM },
        .required.count = { 1,               1         },

        .result = STONE_ACORN_ITEM
    },

    // Sand Acorn: craft from a dirt acorn and wheat
    {
        .required.items = { DIRT_ACORN_ITEM, WHEAT_ITEM },
        .required.count = { 1,               1          },

        .result = SAND_ACORN_ITEM
    }
};

const struct crafting_Recipe furnace_recipes[FURNACE_RECIPES] = {
    // Iron Ingot
    {
        .required.items = { IRON_ORE_ITEM, COAL_ITEM },
        .required.count = { 4,             1         },

        .result = IRON_INGOT_ITEM
    },

    // Gold Ingot
    {
        .required.items = { GOLD_ORE_ITEM, COAL_ITEM },
        .required.count = { 4,             1         },

        .result = GOLD_INGOT_ITEM
    },

    // Glass
    {
        .required.items = { SAND_ITEM, COAL_ITEM },
        .required.count = { 4,         1         },

        .result = GLASS_ITEM
    },

    // === New Furnace Recipes for Skyblock Progression ===

    // Coal: smelt wood into coal
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 4 },

        .result = COAL_ITEM
    },

    /*
     * Remove the furnace recipe that hardens dirt and coal into stone.
     * Stone must now be acquired through mining or other progression
     * rather than crafted directly.  This deletion lowers the size
     * of the furnace recipe array by one entry.
     */
    // === Skyblock Furnace Recipes ===

    // Iron Acorn: smelt a stone acorn with sand, dirt and coal
    {
        .required.items = { STONE_ACORN_ITEM, SAND_ITEM, DIRT_ITEM, COAL_ITEM },
        .required.count = { 1,                1,         1,         1         },

        .result = IRON_ACORN_ITEM
    },

    // Gold Acorn: smelt an iron acorn with seeds, an apple, slime and glass
    {
        .required.items = { IRON_ACORN_ITEM, SEEDS_ITEM, APPLE_ITEM, SLIME_ITEM, GLASS_ITEM },
        .required.count = { 1,               1,          1,          1,          1          },

        .result = GOLD_ACORN_ITEM
    },

    // Gem Acorn: smelt one of each acorn plus several materials.  This
    // recipe uses many ingredients, which is why CRAFTING_MAX_REQUIRED
    // was increased.  Each component is consumed once.
    {
        .required.items = { ACORN_ITEM, STONE_ACORN_ITEM, SAND_ACORN_ITEM, IRON_ACORN_ITEM, GOLD_ACORN_ITEM, GOLD_INGOT_ITEM, IRON_INGOT_ITEM, SAND_ITEM, STONE_ITEM, DIRT_ITEM, GEM_ITEM },
        .required.count = { 1,          1,               1,              1,               1,               1,               1,               1,        1,         1,        1 },

        .result = GEM_ACORN_ITEM
    }
};

const struct crafting_Recipe oven_recipes[OVEN_RECIPES] = {
    // Bread
    {
        .required.items = { WHEAT_ITEM },
        .required.count = { 4 },

        .result = BREAD_ITEM
    }
};

const struct crafting_Recipe anvil_recipes[ANVIL_RECIPES] = {
    // Iron Tools

    // Iron Sword
    {
        .required.items = { WOOD_ITEM, IRON_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = SWORD_ITEM,
        .tool_level = 2
    },

    // Iron Axe
    {
        .required.items = { WOOD_ITEM, IRON_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = AXE_ITEM,
        .tool_level = 2
    },

    // Iron Hoe
    {
        .required.items = { WOOD_ITEM, IRON_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = HOE_ITEM,
        .tool_level = 2
    },

    // Iron Pick
    {
        .required.items = { WOOD_ITEM, IRON_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = PICK_ITEM,
        .tool_level = 2
    },

    // Iron Shovel
    {
        .required.items = { WOOD_ITEM, IRON_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = SHOVEL_ITEM,
        .tool_level = 2
    },

    // Gold Tools

    // Gold Sword
    {
        .required.items = { WOOD_ITEM, GOLD_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = SWORD_ITEM,
        .tool_level = 3
    },

    // Gold Axe
    {
        .required.items = { WOOD_ITEM, GOLD_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = AXE_ITEM,
        .tool_level = 3
    },

    // Gold Hoe
    {
        .required.items = { WOOD_ITEM, GOLD_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = HOE_ITEM,
        .tool_level = 3
    },

    // Gold Pick
    {
        .required.items = { WOOD_ITEM, GOLD_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = PICK_ITEM,
        .tool_level = 3
    },

    // Gold Shovel
    {
        .required.items = { WOOD_ITEM, GOLD_INGOT_ITEM },
        .required.count = { 5,         5               },

        .result = SHOVEL_ITEM,
        .tool_level = 3
    },

    // Gem Tools

    // Gem Sword
    {
        .required.items = { WOOD_ITEM, GEM_ITEM },
        .required.count = { 5,         50       },

        .result = SWORD_ITEM,
        .tool_level = 4
    },

    // Gem Axe
    {
        .required.items = { WOOD_ITEM, GEM_ITEM },
        .required.count = { 5,         50       },

        .result = AXE_ITEM,
        .tool_level = 4
    },

    // Gem Hoe
    {
        .required.items = { WOOD_ITEM, GEM_ITEM },
        .required.count = { 5,         50       },

        .result = HOE_ITEM,
        .tool_level = 4
    },

    // Gem Pick
    {
        .required.items = { WOOD_ITEM, GEM_ITEM },
        .required.count = { 5,         50       },

        .result = PICK_ITEM,
        .tool_level = 4
    },

    // Gem Shovel
    {
        .required.items = { WOOD_ITEM, GEM_ITEM },
        .required.count = { 5,         50       },

        .result = SHOVEL_ITEM,
        .tool_level = 4
    }
};

// === Basic Crafting Table Recipes ===
//
// The basic crafting table is an introductory crafting station that
// allows the player to create a full workbench.  It contains only
// one recipe: convert four wood into one workbench.  No tool level
// upgrade is required or granted by this recipe.
const struct crafting_Recipe basic_workbench_recipes[BASIC_WORKBENCH_RECIPES] = {
    {
        .required.items = { WOOD_ITEM },
        .required.count = { 4 },
        .result = WORKBENCH_ITEM,
        .tool_level = 0
    }
};

u8 crafting_current_recipes_size;
const struct crafting_Recipe *crafting_current_recipes;

bool crafting_craft(struct Inventory *inventory,
                    const struct crafting_Recipe *recipe) {
    // add item to the inventory
    if(item_is_resource(recipe->result)) {
        if(!inventory_add_resource(inventory, recipe->result, 1, 0))
            return false;
    } else {
        struct item_Data to_add = { .type = recipe->result };

        if(ITEM_S(&to_add)->class == ITEMCLASS_TOOL)
            to_add.tool_level = recipe->tool_level;

        if(to_add.type == CHEST_ITEM) {
            to_add.chest_id = furniture_new_chest_id();

            if(to_add.chest_id >= CHEST_LIMIT)
                return false;
        }

        if(!inventory_add(inventory, &to_add, 0))
            return false;
    }

    // remove the required items
    // (assume that the inventory contains them)
    for(u32 i = 0; i < CRAFTING_MAX_REQUIRED; i++) {
        const u8 item_type = recipe->required.items[i];
        const u8 count     = recipe->required.count[i];

        if(count == 0)
            continue;

        inventory_remove_resource(inventory, item_type, count);
    }

    return true;
}
